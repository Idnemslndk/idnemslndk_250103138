public class FlightBookingFacade {
    private SeatInventorySystem seat;
    private BaggagePricingEngine baggage;
    private CurrencyConverter currencyConverter;
    private PaymentProcessor payment;
    private TicketIssuer ticket;

    public FlightBookingFacade() {
        this.seat = new SeatInventorySystem();
        this.baggage = new BaggagePricingEngine();
        this.currencyConverter = new CurrencyConverter();
        this.payment = new PaymentProcessor();
        this.ticket = new TicketIssuer();
    }

    public String bookFlight(String passengerName, String flightCode, String seatNumber, double baseFareUSD, int bagCount,
                             double bagWeightKg, String currency, String cardNumber) {
        String lockToken = null;
        try {
// TODO 1: Connect to seat server and lock the requested seat.
            seat.connectToReservationServer();
            String lockTokens = seat.lockSeat(flightCode, seatNumber, passengerName);

// TODO 2: Compute baggage fee in USD and add to baseFareUSD.
            baseFareUSD += baggage.calculateBaggageFeeUSD(bagCount, bagWeightKg);

// TODO 3: Convert total USD amount into target currency.
            baseFareUSD = currencyConverter.convertFromUSD(baseFareUSD,currency);
// TODO 4: Initialize payment gateway and charge the card.
            payment.initializeGateway();
            payment.chargeCard(cardNumber, baseFareUSD,currency);
// TODO 5: Generate and return the final e-ticket code.
            ticket.generateTicket(passengerName,flightCode,lockTokens,payment.)
            return "";
        } catch (RuntimeException ex) {
// TODO 6: If a seat was already locked, release it before reporting failure.
            return "BOOKING_FAILED: " + ex.getMessage();
        } finally {
// TODO 7: Ensure seat server disconnects regardless of success or failure.

        }
    }
}

